﻿using System;
using Finance;

namespace ClientExe
{
    class Program
    {
        static void Main(string[] args)
        {
            Account ac1, ac2;
            ac1 = new Account("Fred", 100);
            ac2 = new Account("Susy");
            ac1.Deposit(100);
            ac2.Withdraw(300);
            Account.Transfer(ac1, ac2, 50);
            Console.WriteLine(ac1.GetDetails());
            Console.WriteLine(ac2.GetDetails());


            // Challenge 1
            Console.WriteLine("\nChallenge 1");
            Account[] accs = { ac1, ac2 };
            ProcessAccounts(accs);
            // will need changing soon
            Console.WriteLine("{0}\t{1:C}", ac1.GetHolder(), ac1.GetBalance());
            Console.WriteLine("{0}\t{1:C}", ac2.GetHolder(), ac2.GetBalance());
            Console.WriteLine();

            // Challenge 2
            Console.WriteLine("\nChallenge 2");
            string[] names = { "Amy", "Anne", "Amira", "Anneka", "Annabel" };
            Account[] studentAccs = new Account[names.Length];
            Random r = new Random();
            for (int i = 0; i < studentAccs.Length; i++)
            {
                studentAccs[i] = new Account(names[i], r.Next(10,100));
            }
            Print(studentAccs);
            Console.WriteLine();
            // transfer money from each student in the array to the next one
            // and lastly from the final student to the first one 
            for (int i = 0; i < studentAccs.Length; i++)
            {
                //if (i < studentAccs.Length - 1)
                //{
                //    // change soon
                //    Account.Transfer(studentAccs[i], studentAccs[i + 1], studentAccs[i].GetHolder().Length);
                //}
                //else
                //{
                //    // change soon
                //    Account.Transfer(studentAccs[i], studentAccs[0], studentAccs[i].GetHolder().Length);
                //}
                // or
                int toAcc = (i + 1) % studentAccs.Length;
                decimal trfAmt = studentAccs[i].GetHolder().Length;
                Account.Transfer(studentAccs[i], studentAccs[toAcc], trfAmt);
            }
            Console.WriteLine();
            Print(studentAccs);

        }

        private static void Print(Account[] studentAccs)
        {
            foreach (Account a in studentAccs)
            {
                Console.WriteLine(a.GetDetails());
            }
        }

        private static void ProcessAccounts(Account[] accs)
        {
            foreach (Account a in accs)
            {
                a.Deposit(10);
            }
        }
    }
}
