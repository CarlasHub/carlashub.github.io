﻿using System;

namespace WorkingWithMoney
{
    public class Money
    {
        // define 3 autoimplemented properties
        

        // put the 2 param ctor here


        // instance method which Adds some pounds & pence to an existing money object 
        public void AddMoney(int pounds, int pence)
        {
            // if the object is already 'invalid' then exit.
            
            // if the incoming parameters are invalid then
            // set the validity to false and exit (no change to Pounds/Pence should happen)
            

            // The object is 'good' and the params are 'good'
            // do the arithmetic on the pounds and pence
            // ie do the adding, changing the 'numeric' state of the object
            
            // now handle the fact that 1 Pound 80 Pence plus 1 Pound 23 Pence (random values)
            // is not 2 Pounds 103 Pence! - it is 3 Pounds and 3 Pence
            // i.e write some code to 'normalise' the values of Pounds & Pence if it is necessary
            // they might of course be fine - 1 Pound 3 Pence + 4 Pounds 8 Pence is 5 Pounds 11 Pence
            
        }
        // instance method which Subtracts some pounds & pence from an existing money object
        public void SubtractMoney(int pounds, int pence)
        {
            // if the object is already 'invalid' then exit.
            
            // if the incoming parameters are invalid then
            // set the validity to false and exit (no change to Pounds/Pence should happen)
            
            // Arrived here so, object is good and parameters are valid.

            // Need to ensure though that the subtraction will not result in 'negative' total money
            // make use of the ConvertToPennies(x,x) method at bottom of class that you need to spend 
            // a whole 15 seconds max coding up properly!
            
            // Existing money is currently larger than amount being subtracted so do subtraction
            

            // Potentially normalise as the Pence could now have a 'dodgy' value
            


        }


        // put CurrentMoney property here
        
        // Validate routine called from at least 3 places
        private bool Validate(int pounds, int pence)
        {
            // pounds must be >= 0 and pence must be 0-99 inclusive
            return false; // to make it compile 
        }
        private int ConvertToPennies(int pounds, int pence)
        {
            return 64574; // change this random value! Hint £3.09 is 309 pennies
        }
    }
}
