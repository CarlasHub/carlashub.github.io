﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WorkingWithMoney
{
    class Program
    {

        static void Main(string[] args)
        {
            //CtorTesting();

            //AddTesting();

            //SubtractTesting();

        }
        /*
        private static void CtorTesting()
        {
            // Create the objects
            Money m1 = new Money(-1, 50); // Pounds too low
            Money m2 = new Money(1, -1);  // Pence too low
            Money m3 = new Money(1, 100); // Pence too high
            Money m4 = new Money(1, 0);   // Good object
            Money m5 = new Money(1, 99);  // Good object


            // Checking validity is correct 
            Console.WriteLine("Ctor and initial property value testing");
            Console.WriteLine("---------------------------------------");

            Console.WriteLine("\nValidity Values - VALIDMONEY property:");
            Console.WriteLine("Actual:   {0} {1} {2} {3} {4}",
                      m1.ValidMoney, m2.ValidMoney, m3.ValidMoney, m4.ValidMoney, m5.ValidMoney);
            // code up this line as to what you would expect
            Console.WriteLine("Expected: ?? ?? ?? ?? ??");

            Console.WriteLine("\nCurrentMoney Values - CURRENTMONEY property");
            Console.WriteLine("Actual:   {0} {1} {2} {3} {4}",
                m1.CurrentMoney, m2.CurrentMoney, m3.CurrentMoney,
                m4.CurrentMoney, m5.CurrentMoney);
            // code up this line as to what you would expect
            Console.WriteLine("Expected: {0} {1} {2} {3} {4}",
                "?", "?", "?", "?", "?");


        }

        private static void AddTesting()
        {
            Money m1 
            = new Money(1, 90);
            m1.AddMoney(2, 9);  // adding good to good no overflow --> 3 & 99

            Money m2 
            = new Money(1, 90);
            m2.AddMoney(2, 10); // adding good to good with overflow --> 3 & 100 becomes 4 & 0

            Money m3 
            = new Money(-1, 50);
            m3.AddMoney(0, 20); // adding good values to an already bad object -> object unchanged

            Money m4 
            = new Money(1, 50);
            m4.AddMoney(0, -20); // adding bad values to a good obejct --> object becomes bad
           
            Console.WriteLine("\nAdd Tests");
            Console.WriteLine("---------");
            Console.WriteLine("\nValidity Values - VALIDMONEY property:");
            Console.WriteLine("Actual:   {0} {1} {2} {3}",
                        m1.ValidMoney, m2.ValidMoney, m3.ValidMoney, m4.ValidMoney);
            // code up this line as to what you would expect
            Console.WriteLine("Expected: ?? ?? ?? ??");

            Console.WriteLine("\nCurrentMoney Values - CURRENTMONEY property");
            Console.WriteLine("Actual:   {0} {1} {2} {3}",
                        m1.CurrentMoney, m2.CurrentMoney, m3.CurrentMoney, m4.CurrentMoney);
            // code up this line as to what you would expect
            Console.WriteLine("Expected: {0} {1} {2} {3}",
                                       "?", "?", "?", "?");
        }

        private static void SubtractTesting()
        {
            Money m1
                 = new Money(3, 20);
            m1.SubtractMoney(2, 20);  // subtracting good from good no underflow --> 1 & 0

            Money m2
                 = new Money(3, 20);
            m2.SubtractMoney(2, 21); // subtracting good to good with underflow --> 1 & -1 becomes 0 & 99

            Money m3
            = new Money(-2, 50);
            m3.SubtractMoney(1, 20); // subtracting good values from a bad object -> object unchanged

            Money m4
            = new Money(2, 50);
            m4.SubtractMoney(1, -20); // subtracting bad values from a good object --> object becomes bad

            Money m5
            = new Money(2, 50);
            m5.SubtractMoney(2, 51); // subtracting more money than you have --> object becomes bad

            Console.WriteLine("\nSubtract Tests");
            Console.WriteLine("--------------");
            Console.WriteLine("\nValidity Values - VALIDMONEY property:");
            Console.WriteLine("Actual:   {0} {1} {2} {3} {4}",
                        m1.ValidMoney, m2.ValidMoney, m3.ValidMoney, m4.ValidMoney, m5.ValidMoney);
            // code up this line as to what you would expect
            Console.WriteLine("Expected: ?? ?? ?? ?? ??");

            Console.WriteLine("\nCurrentMoney Values - CURRENTMONEY property");
            Console.WriteLine("Actual:   {0} {1} {2} {3} {4}",
                        m1.CurrentMoney, m2.CurrentMoney, m3.CurrentMoney, m4.CurrentMoney, m5.CurrentMoney);
            // code up this line as to what you would expect
            Console.WriteLine("Expected: {0} {1} {2} {3} {4}",
                                "?", "?", "?", "?", "?");
        }
        */ // this block comment enabled starter to compile before properties are defined by you
    }
}
