﻿using System;

namespace Finance
{
    public class Account
    {
        // private instance fields
        private string holder;
        private decimal balance;
        private string accNo;

        // private static fields
        private static int nxtAccNo;
        private static decimal overdraftLimit = 500;

        //ctors
        public Account(string name, decimal balance)
        {
            holder = name;
            this.balance = balance;
            accNo = "SA-" + (++nxtAccNo).ToString().PadLeft(4, '0');
        }
        
        public Account(string name) : this(name, 0) { }

        public string GetDetails()
        {
            return string.Format("{0}\t{1}\t{2:C}", accNo, holder, balance);
        }

        public decimal GetBalance()
        {
            return balance;
        }
        
        public string GetHolder()
        {
            return holder;
        }

        public void Deposit(decimal amt)
        {
            balance += amt;
        }
        
        public bool Withdraw(decimal amt)
        {
            bool result = false;
            if (amt <= this.balance + Account.overdraftLimit)
            {
                balance -= amt;
                result = true;
            }

            return result;
        }

        public static bool Transfer(Account from, Account to, decimal amt)
        {
            bool result = false;

            if (from.Withdraw(amt))
            {
                to.Deposit(amt);
                result = true;
            }
            Console.WriteLine("Transfer of {0:C} Successful: {1}", amt, result ? "YES" : "NO");
            return result;
        }

    }
}
